import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Star } from "lucide-react";

export default function PromoPlus() {
  return (
    <div className="bg-black text-white min-h-screen font-sans">
      <section className="text-center py-28 bg-gradient-to-b from-black to-gray-900 relative overflow-hidden">
        <motion.div
          className="absolute top-10 left-10 w-32 h-32 bg-white/5 rounded-full blur-3xl"
          animate={{ y: [0, 30, 0] }}
          transition={{ duration: 6, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-10 right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"
          animate={{ y: [0, -40, 0] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
          <div className="flex justify-center mb-6">
            <div className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-full font-bold text-xl">
              <Star className="w-5 h-5" /> PromoPlus
            </div>
          </div>
          <h1 className="text-5xl font-extrabold mb-4 tracking-tight">Promote. Connect. Grow.</h1>
          <p className="text-gray-300 text-lg max-w-xl mx-auto">The ultimate platform for local and online business promotion.</p>
        </motion.div>
      </section>
    </div>
  );
}